ontoDepth <- function (rg)
{
    g <- DAG(rg)
    R <- root(rg)
    nd <- nodes(g)
#    rg <- revArcs(g)
    dvec <- rep(NA, length(nd))
    names(dvec) <- nd
    tls <- names(eg <- edges(g))
    lel <- unlist(lapply(eg, length))
    tls <- rep(tls, lel)
    tps <- unlist(edges(g))
    ntps <- tls
    names(ntps) <- tps
    ntps <- ntps[!is.na(names(ntps))] # some roots have it
    dvec[R] <- 0
    dvec[ntps[names(ntps) == R]] <- 1
lastdone <- 1
while (any(is.na(dvec)))
   {
    dvec[ntps[names(ntps) %in% names(dvec[dvec == lastdone])]] <- lastdone+1
   lastdone <- lastdone+1
   }
    dvec
}

depthStruct <- function(rg)
{
dvec <- ontoDepth(rg)
tag2depth <- new.env(hash=TRUE)
depth2tags <- new.env(hash=TRUE)
nms <- names(dvec)
dps <- as.numeric(dvec)
for (i in 1:length(nms))
 {
 assign(nms[i], dps[i], env=tag2depth)
 }
for (d in 0:max(unique(round(dps,0))))
 {
 assign(as.character(d), nms[round(dvec,0)==d], env=depth2tags)
 }
list(tag2depth=function(x) tag2depth[[x]],
     depth2tags=function(x)depth2tags[[as.character(x)]])
}
