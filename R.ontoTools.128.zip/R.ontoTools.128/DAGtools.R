#
# very primitive approach because RBGL is not
# in windows yet.  but would like to have validation
# of DAG structure at construction time

setClass("rootedDAG",
	representation(root="character", DAG="graph"))

setGeneric("root", function(x)standardGeneric("root"))
setMethod("root", "rootedDAG", function(x) x@root)
setGeneric("DAG", function(x)standardGeneric("DAG"))
setMethod("DAG", "rootedDAG", function(x) x@DAG)
setGeneric("getMatrix", function(g,type,mode)
	standardGeneric("getMatrix"))
setMethod("getMatrix", c("rootedDAG", "character", "character"),
	function(g,type,mode) {
		if (type != "child2parent")
			stop("only type 'child2parent' supported")
		if (mode == "dense")
			return(child2parentMatDense(DAG(g)))
		if (mode == "sparse")
			return(child2parentMatSparse(DAG(g)))
		else stop("mode must be 'sparse' or 'dense'")
	})

child2parentMatDense <- function(g) {
 nd <- nodes(g)
 el <- edges(g)
 tails <- names(el)
 out <- matrix(0,nr=length(nd),nc=length(nd))
 dimnames(out) <- list(nd,nd)
 for (tl in tails)
   {
   for (tip in el[[tl]])
     out[tl,tip] <- 1
   }
 out
}

child2parentMatSparse <- function(g)
{
    nd <- nodes(g)
    mape <- new.env(hash = TRUE)
    for (i in 1:length(nd)) assign(nd[i], i, env = mape)
    map <- function(tag) mape[[tag]]
    el <- edges(g)
    tails <- names(el)
    sinit <- makeSparseZero(length(nd), length(nd))#as.matrix.csr(0, nrow = length(nd), ncol = length(nd))
    i <- 0
    for (tl in tails) {
        i <- i + 1
        if (i%%250 == 0)
            cat(i)
        for (tip in el[[tl]]) if (!is.na(tip))
            sinit[map(tl), map(tip)] <- 1
    }
    sinit
}

#setMethod("depth", c("rootedDAG","missing"), function(x,maxd=50) {
# mat <- getMatrix(x, "child2parent", "sparse")
# d <- 0
# tmp <- mat
# while (maxval(tmp) > 0)
#   {
#   d <- d+1
#   tmp <- tmp %*% mat
#   }
# d
#})

