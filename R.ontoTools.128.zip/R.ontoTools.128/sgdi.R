setOldClass("ordered")

setClass("provStruct", representation(
 URI="character", captureDate="character",
 comment="character"))

setMethod("show", "provStruct", function(object) {
 cat("provenance: source = ", object@URI, "\n")
 cat("          : date = ", object@captureDate, "\n") }
)

# inMappings is a vector of symMapping references(names)
setClass("nomenclature", representation( name="character",
 provenance="provStruct", inMappings="character",
 terms="character", definitions="character"))

setClass("taggedHierNomenclature", representation( tags="character",
  parents="character", delim="character",
  rootToken="character"), contains="nomenclature")

# above reflects the flat file structure of NCI Thesaurus
# delim is what you use to split strings in parents field to
# get actual parents, rootToken is token used to indicate no parents

setMethod("show", "taggedHierNomenclature", function(object) {
 cat("GDI hierarchical nomenclature with tags.\n")
 cat("First 10 tags: ", object@tags[1:10], "\n")
 callNextMethod()
})

setClass("GDIontology", representation(
 name="character", version="ordered",
 graph="graph"), contains="nomenclature") # use DAG with convention
                                          # tail->head is towards generality

setMethod("show", "nomenclature", function(object) {
 cat("GDI nomenclature: ", object@name, "\n")
 show(object@provenance)
 cat("There are", length(object@terms), "terms.\n")
 cat("First 5 terms/definitions\n")
 cln <- function(x) ifelse(nchar(x)>30, paste(substr(x,1,30),"..",sep=""), x)
 print(cbind(terms=object@terms[1:5], defs=cln(object@definitions[1:5])))
 cat("GDI maps:\n")
 print(object@inMappings)
})

setGeneric("parents", function(term,nom)standardGeneric("parents"))
setMethod("parents", c("character", "taggedHierNomenclature"),
 function(term,nom) {
  ind <- which(nom@terms==term)
  if (length(ind)==0) stop(paste("term not found in nomenclature",nom@name))
  if (length(ind)>1) warning("multiple matches found, using first")
  if (nom@parents[ind[1]]==nom@rootToken) return(nom@rootToken)
  strsplit(nom@parents[ind[1]],nom@delim)[[1]]
})

setGeneric("children", function(term,nom)standardGeneric("children"))
setMethod("children", c("character", "taggedHierNomenclature"),
 function(term,nom) {
  ind <- grep(term,nom@parents)
  if (length(ind) == 0) stop("term not found in parent field of any other term")
  nom@terms[ind]
})



#function (pattern, x, ignore.case = FALSE, extended = TRUE, perl = FALSE,
#    value = FALSE, fixed = FALSE, useBytes = FALSE)


setMethod("grep", c("character", "taggedHierNomenclature"),
	function(pattern, x, ignore.case, perl, value, fixed, useBytes  ) {
		inds <- grep( pattern, x@terms, ignore.case=TRUE )
		if (length(inds)==0) stop("term not found")
		ans <- x@terms[inds]
		names(ans) <- x@tags[inds]
		ans
	})

setGeneric("getTerms",
           function(ob) standardGeneric("getTerms"))

setMethod("getTerms", "taggedHierNomenclature", function(ob)
 {
 tms <- ob@terms
 names(tms) <- ob@tags
 tms
 })

setClass("annotationResource", representation(
 name="character", baseNomenclature="nomenclature",
 version="ordered"))

setClass("symMapping", representation(
 basename="character", key="character",
 value="data.frame"))

setClass("typedSymMapping", representation(
 typeStructure="data.frame"), contains="symMapping")

setMethod("show", "symMapping", function(object) {
 cat("GDI mapping from", object@basename, "to\n")
	print(names(object@value))
 feas <- min(length(object@key), 10)
 cat("First", feas, " mappings:\n")
 x <- object@value[1:feas,]
 rownames(x) <- object@key[1:feas]
 print(x) })

#require(hgu95av2)
#require(hu6800)
#hgu95av2map <- new("symMapping", basename="hgu95av2", 
# key = ls(hgu95av2SYMBOL), value=
#   data.frame(SYM=unlist(eapply(hgu95av2SYMBOL,function(x)x)),
#              REFSEQ1=unlist(eapply(hgu95av2REFSEQ,function(x)x[1])),
#              LL1=unlist(eapply(hgu95av2LOCUSID,function(x)x[1]))))
#hu6800map <- new("symMapping", basename="hu6800", 
# key = ls(hu6800SYMBOL), value=
#   data.frame(SYM=unlist(eapply(hu6800SYMBOL,function(x)x)),
#              REFSEQ1=unlist(eapply(hu6800REFSEQ,function(x)x[1])),
#              LL1=unlist(eapply(hu6800REFSEQ,function(x)x[1]))))
#hu6800map <- new("symMapping", basename="hu6800", destname="SYM",
# key = ls(hu6800SYMBOL), value=unlist(eapply(hu6800SYMBOL,function(x)x)))

setClass("GDIplatform", representation(
 name="character", probeids="symMapping"))

#hgu95av2plat <- new("GDIplatform", name="hgu95av2",
# probeids=hgu95av2map)
#hu6800plat <- new("GDIplatform", name="hu6800",
# probeids=hu6800map)

setMethod("show", "GDIplatform", function(object) {
 cat("GDI platform object", object@name, "\n")
 show(object@probeids) })

setGeneric("getDefs",
           function(term, nom) standardGeneric("getDefs"))
setMethod("getDefs", c("character", "nomenclature"),
	function(term,nom) {
		wh <- which(nom@terms==term)
		nom@definitions[wh]
		})

setClass("GDILabel", representation(
 basis="character"), contains="character")

setClass("exptArchive", representation(
 tag="character", 
 platform="GDIplatform"), contains="ExpressionSet")

setMethod("show", "exptArchive", function(object) {
 cat("GDI experiment archive ID =", object@tag, "\n")
 cat("GDI platform =", object@platform@name, "\n")
 cat("There are", nrow(pData(object)), "samples present.\n")
 cat("Covariates present on:\n")
 print( names(pData(object)) )
}) 

setClass("exptSample", representation(
 assaydata="ANY", covdata="ANY"))

setMethod("show", "exptSample", function(object) {
 cat("GDI experiment sample;", length(object@assaydata),
 "assay elements;", length(object@covdata), "covariate elements.\n")})

#library(golubEsets)
#data(golubMerge)
#ad <- exprs(golubMerge[,1])
#cd <- pData(golubMerge[,1])
#g1 <- new("exptSample", assaydata=ad, covdata=cd)
#golarch <- new("exptArchive", tag="GolubLeuk", platform=hu6800plat)
#golarch[[1]] <- g1
#for (i in 2:ncol(exprs(golubMerge))) {
# ad <- exprs(golubMerge[,i])
# cd <- pData(golubMerge[,i])
# golarch[[i]] <-  new("exptSample", assaydata=ad, covdata=cd)
#}

setClass("annoSource", representation(
 name="character", keytype="character",
 mapping="ANY"))


#exptTypes is an ontology of experiment types (e.g, microarray, SAGE)
#
#exptDesigns is an ontology of experiment designs
#
#AllExpts is the set of references to exptArchive instances
#Biometadata is the set of references to annoSource instances
#
#Let e be an instance of exptArchive.  we assume it is a table
#keyed by references to a (catalog of) biological entity like a gene, attributes
#are assay values for different samples
#
#bioKey(e) is the vector of primary keys; the key type (e.g. LL, UG) 
#  must be bound to it somehow (an object of class GDILabel)
#
#platform(e) is the GDIplatform object describing the platform used;
#  
#conditions(e)  is the list of GDILabels describing the clinical
#  conditions relevant to the experiment (ALL vs AML, using NCI
#  thesaurus or other formally established descriptors.  Local
#  descriptor namespaces are allowed.)
#
#samples(e) is the list of exptSamples in e
#
#Let s be an instance of exptSample from e
#
#bioData(s) is the assay output (e.g., the exprs column)
#covData(s) is the covariate data, which will include elements from 
#  conditions(e)
#

