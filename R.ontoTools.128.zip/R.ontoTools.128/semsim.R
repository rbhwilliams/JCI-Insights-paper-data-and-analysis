#
# code to implement ideas from Lord et al Semantic similarity paper
#

usageCount <- function (map, acc, inds) 
{
    maptms <- dimnames(map)[[2]]
    acctms <- dimnames(acc)[[2]]
    usages <- rep(0,length(maptms))
    names(usages) <- maptms
    if (is.null(inds)) inds <- 1:nrow(map)
    cat(paste("progress in (", min(inds),",", max(inds),"):\n"))
    for (i in inds) {
        if ((i %% 5) == 0) cat(i)
        if ((i %% 200) == 0) cat("\n")
        hits <- maptms[as.matrix.ok(map[i, ]) == 1]
        if (length(hits)==0) next
        usages[hits] <- usages[hits] + 1
        for (j in 1:length(hits)) {
            anctags <- acctms[as.matrix.ok(acc[hits[j], ]) == 1]
            anctags <- intersect(anctags, maptms) # some hits may
                       # have ancestor terms to which there is no mapping
                       # from object set (e.g. LL loci)
            usages[anctags] <- usages[anctags] + 1
        }
    }
    tmp <- usages
    attr(tmp,"inds") <- inds
    tmp
}


conceptProbs <- function(ooc,acc=NULL,inds=NULL) {
 if (! is(ooc, "OOC")) stop("arg must have class OOC")
 oom <- OOmap(ooc)
 if (is.null(acc)) acc <- accessMat(ontology(ooc))
 uc <- usageCount(oom, acc, inds)
 tmp <- uc/max(uc,na.rm=TRUE)
 attr(tmp,"inds") <- inds
 attr(tmp,"uc") <- uc
 tmp
}

subsumers <- function(c1, c2, ont, acc=NULL) {
 if (! is(ont, "ontology")) stop("ont must have class ontology")
 if (is.null(acc)) acc <- accessMat(ont)
 tmp <- colSums(acc[c(c1,c2),])
 names(tmp[tmp==2])
}

pms <- function(c1, c2, ooc, acc=NULL, pc=NULL) {
 #probability of minimum subsumer
 # a problem here is that the acc is not necessarily
 # compatible with the ooc map.  we don't always want
 # to compute it at this time, but when we move to C
 # we probably can use just the ooc and not allow
 # passage of an acc
 if (! is(ooc, "OOC")) stop("arg must have class OOC")
 if (any(!(c(c1,c2) %in% nodes(DAG(rDAG(ontology(ooc))))))) 
     stop("some term not found in ontology DAG nodes")
 S <- subsumers(c1,c2,ontology(ooc),acc)
 S <- intersect(S, dimnames(OOmap(ooc))[[2]]) # get rid of subsumers
          # in this acc to which no object was mapped
 if (is.null(pc)) pc <- conceptProbs(ooc,acc,pc)
 min(pc[S])
}

semsim <- function(c1, c2, ooc, acc=NULL, pc=NULL) 
 -log(pms(c1,c2,ooc,acc,pc))


