
makeSparseZero <- function(nr,nc)
 {
 new("matrix.csr", ra = 0, ja = as.integer(1), ia = as.integer(c(1:1,  
    rep(2, nr))), dimension = as.integer(c(nr,nc)))
 }

