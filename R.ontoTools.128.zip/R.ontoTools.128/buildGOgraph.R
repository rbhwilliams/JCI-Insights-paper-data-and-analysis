buildGOgraph <- function(useenv=GOMFPARENTS) {
 library(GO.db)
 library(Biobase)
 library(graph)
 nds <- unique(ls(useenv))
 eds <- mget( nds, useenv, ifnotfound=NA )
 eds <- lapply( eds, function(x) {
     lk <- match(x,nds)
     if (length(lk)==0) return(list(edges=character(0)))
     else if (length(lk)==1 && is.na(lk)) return(list(edges=character(0)))
     else if (any(is.na(lk))) return(list(edges=lk[!is.na(lk)]))
     return(list(edges=lk))
     })
 tmp <- new("graphNEL", nodes=nds, edgeL=eds, edgemode="directed")
 attr(tmp,"toolInfo") <- library(help=GO.db)$info[[1]][c(1,4)]
 updateGraph(tmp)  # not clear why
}

