otkvEnv2namedSparse <- function(obs, tms, otkvEnv) {
#
# object-term key-value environment converted to
# named sparse matrix
#
# very slow for large matrices!
#
# object term key-value list
# args seem excessive but need to account for a list that doesn't map to all terms
lnames <- ls(env=otkvEnv)
if (!(all(lnames %in% obs))) stop("some kvlist names not in obs vec")
mat <- makeSparseZero(length(obs), length(tms))# as.matrix.csr(0.0,nrow=length(obs),ncol=length(tms))
for (i in 1:length(lnames))
 {
 if (i %% 100 == 0) cat(i)
 curob <- lnames[i]
 rind <- match(curob,obs)
 cind <- match(otkvEnv[[curob]], tms)

 if (any(is.na(cind)) | is.na(rind)) next
 mat[ rind, cind ] <- 1.0
# for (j in 1:length(targc))
#    {
#    cind <- targc[j]
#    if (is.na(cind) | is.na(rind)) next
#    mat[ rind, cind ] <- 1.0
#    }
 }
new( "namedSparse", mat=mat, Dimnames=list(obs,tms))
}

otkvList2namedSparse <- function(obs, tms, otkvlist) {
# object term key-value list
# args seem excessive but need to account for a list that doesn't map to all terms
lnames <- names(otkvlist)
if (!(all(lnames %in% obs))) stop("some kvlist names not in obs vec")
mat <- makeSparseZero(length(obs), length(tms))# as.matrix.csr(0.0,nrow=length(obs),ncol=length(tms))
for (i in 1:length(otkvlist))
 {
 if (i %% 100 == 0) cat(i)
 curob <- lnames[i]
 rind <- match(curob,obs)
 targc <- match( otkvlist[[curob]], tms )
 for (j in 1:length(targc))
    {
    cind <- targc[j]
    if (is.na(cind) | is.na(rind)) next
    mat[ rind, cind ] <- 1.0
    }
 }
new( "namedSparse", mat=mat, Dimnames=list(obs,tms))
}
