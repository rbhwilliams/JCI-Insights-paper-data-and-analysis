require(SparseM)

#
# all index manipulations via Dimnames
#

setClass("namedSparse",
	representation(Dimnames="list", mat="matrix.csr"))

setMethod("dimnames", "namedSparse", function(x) x@Dimnames)

setGeneric("rowinds", function(m,tags) standardGeneric("rowinds"))
setGeneric("colinds", function(m,tags) standardGeneric("colinds"))

setGeneric("mat", function(x) standardGeneric("mat"))
setMethod("mat", "namedSparse", function(x) x@mat)

setMethod("[", "namedSparse", def=function(x, i, j, ..., drop=FALSE) {
	exns2(x, i, j ,..., drop=drop) })

exns2 <- function(x, i, j, ..., drop=FALSE) {
  # current SparseM does not use drop, ignore
  # sparseM does not know about boolean indexing
	if (missing(j)) {
		if (missing(i)) return(x)  # missing i and j, RETURN
		coln <- dimnames(x)[[2]]   # have i but not j, compute coln
		colinds <- 1:length(coln)
     		if (is.numeric(i)) rowinds <- i # need to decode i
			else if (is.logical(i)) rowinds <- (1:nrow(x))[i]
			else if (is.character(i)) rowinds <- 
                              match(i,dimnames(x)[[1]])
			else stop(paste("cannot handle index of class",class(i)))
		rown <- dimnames(x)[[1]][rowinds]
		}
  	else {     # have j, don't know about i
     		if (is.numeric(j)) colinds <- j  # decode j
			else if (is.logical(j)) colinds <- (1:ncol(x))[j]
			else if (is.character(j)) colinds <- match(j,dimnames(x)[[2]])
			else stop(paste("cannot handle index of class",class(j)))
		coln <- dimnames(x)[[2]][colinds]
		if (missing(i)) {  # have j but no i, RETURN with j restrict
			return(new("namedSparse", mat=mat(x)[,colinds],
				Dimnames=list(dimnames(x)[[1]], coln)))
			}  # now have i and j, need to decode i
     		if (is.numeric(i)) rowinds <- i # need to decode i
			else if (is.logical(i)) rowinds <- (1:nrow(x))[i]
			else if (is.character(i)) rowinds <- match(i,dimnames(x)[[1]])
			else stop(paste("cannot handle index of class",class(i)))
		rown <- dimnames(x)[[1]][rowinds]
	     }
		return(new("namedSparse", mat=mat(x)[rowinds,colinds],
			Dimnames=list(rown, coln)))
}

setMethod("rowinds", c("namedSparse","character"),
  function(m,tags) {
    match( tags, dimnames(m)[[1]] )
  })
setMethod("colinds", c("namedSparse","character"),
  function(m,tags) {
    match( tags, dimnames(m)[[2]] )
  })
   




#slow method of summing a sparse matrix
sumSpSLOW <- function(x) {
 s <- 0
 nr <- dim(x)[1]
 for (i in 1:nr) {
  if (i %% 250 == 0) cat(i)
  s <- s + SparseM::as.matrix(x[i,])
 }
 s
}

colSumsSp <- function(x) {
# columnwise sums of a sparse matrix
 s <- 0
 nc <- dim(x)[2]
 nr <- dim(x)[1]
 unit <- SparseM::as.matrix.csr(rep(1.0,nr),nrow=1,ncol=nr)
 as.double(SparseM::as.matrix(unit %*% x))
 }
 
rowSumsSp <- function(x) {
# rowwise sums of a sparse matrix
 s <- 0
 nc <- dim(x)[2]
 nr <- dim(x)[1]
 unit <- SparseM::as.matrix.csr(rep(1.0,nc),nrow=nc,ncol=1)
 as.double(SparseM::as.matrix(x %*% unit))
 }

sumSp <- function(x) {
# sum of sparse matrix elements
 sum(colSumsSp(x))
}

#mapNamesInds <- function(cvec) {
# inds <- 1:length(cvec)
# n2imap <- new.env(hash=TRUE)
# i2nmap <- new.env(hash=TRUE)
# for (i in inds)
#  {
#  assign(cvec[i], i, env=n2imap)
#  assign(as.character(i), cvec[i], env=i2nmap)
#  }
# list(n2i=n2imap, i2n=i2nmap)
#}

#setClass("mapStruct", representation(from="character",
#		to="character", forward="environment",
#		reverse="environment"))
#
#
# not happy with this stuff .... need to really
# transparently attach dimnames to sparse matrix
# don't want to do too much because the authors will probably
# do it
#

mkNS <- function(sm)
 {
 d <- dim(sm)
 rn <- paste("R",1:d[1],sep="")
 cn <- paste("C",1:d[2],sep="")
 new("namedSparse", mat=sm, Dimnames=list(rn,cn))
 }


#setClass("namedSparse", 
#	representation(Dimnames="list", mat="matrix.csr",
#		rowindex="list", colindex="list"))

#setGeneric("setNames", function(x,rown,coln) standardGeneric("setNames"))
#setMethod("setNames", c("matrix.csr","character", "character"),
#	function(x,rown,coln) {
#		new("namedSparse",
#			Dimnames=list(rown,coln),
#			mat=x,
#			rowindex=mapNamesInds(rown),
#			colindex=mapNamesInds(coln))
#	})

setMethod("dimnames<-", c("namedSparse","list"), function(x,value) {
 new("namedSparse", Dimnames=value, mat=x@mat)})

#setGeneric("nrow", function(x)standardGeneric("nrow"))
setMethod("nrow", "namedSparse", function(x) nrow(mat(x)))
#setGeneric("ncol", function(x)standardGeneric("ncol"))
setMethod("ncol", "namedSparse", function(x) ncol(mat(x)))
#setGeneric("Dimnames", function(x)standardGeneric("Dimnames"))
setMethod("dimnames", "namedSparse", function(x) x@Dimnames)
#setGeneric("rowindex", function(x)standardGeneric("rowindex"))
#setMethod("rowindex", "namedSparse", function(x) x@rowindex)
#setGeneric("colindex", function(x)standardGeneric("colindex"))
#setMethod("colindex", "namedSparse", function(x) x@colindex)

		
#setGeneric("as.matrix", function(x)standardGeneric("as.matrix"))
setMethod("as.matrix", "namedSparse", function(x) {
  dd <- dim(mat(x))
  if (max(dd) > 20) stop("not coercing sparse mat with dim>20...do it manually")
  M <- SparseM::as.matrix(x@mat)
  dimnames(M) <- dimnames(x)
  M
})

as.matrix.ok <- function(x, ...) {
  M <- SparseM::as.matrix(x@mat)
  dimnames(M) <- dimnames(x)
  M
}


setGeneric("colSums" , function(x,na.rm=FALSE,dims=1)standardGeneric("colSums"))
setGeneric("rowSums" , function(x,na.rm=FALSE,dims=1)standardGeneric("rowSums"))
setMethod("colSums", c("namedSparse", "missing", "missing"),
 function(x,na.rm=FALSE,dims=1) {
  ans <- colSumsSp(mat(x))
  names(ans) <- dimnames(x)[[2]]
  ans
})
setMethod("rowSums", c("namedSparse", "missing", "missing"),
 function(x,na.rm=FALSE,dims=1) {
  ans <- rowSumsSp(mat(x))
  names(ans) <- dimnames(x)[[1]]
  ans
})

setMethod("Arith", c("namedSparse", "namedSparse"), function(e1,e2)
	stop("that method for namedSparse not implemented yet"))
# sparseM guys did not use e1 e2 convention
setMethod("%*%", c("namedSparse", "namedSparse"), 
	function(x,y) 
	new("namedSparse", mat=mat(x)%*%mat(y), Dimnames=list(
		dimnames(x)[[1]], dimnames(y)[[2]])))


#addsp <- function(x,y) {
#locMCSRaddsub(x,y,1)
#}
#setGeneric("addnsp", function(e1,e2)standardGeneric("addnsp"))
setMethod("+", c("namedSparse", "namedSparse"), function(e1,e2) 
        {
	new("namedSparse", mat=mat(e1)+ mat(e2),
		Dimnames=list(
		dimnames(e1)[[1]], dimnames(e1)[[2]]))
        })


setGeneric("maxval",function(x)standardGeneric("maxval"))
setMethod("maxval", "matrix.csr", function(x)
 {
 nr <- nrow(x)
 mx <- (-Inf)
 for (i in 1:nr) 
  mx <- max(c(mx,SparseM::as.matrix(x[i,])))
 mx
 })
 
assign("%+%", function(x,y) {
 tmp <- x+y
 tmp@ra <- pmin(tmp@ra,1)
 tmp
})

setMethod("show", "namedSparse", function(object) {
 cat("named sparse matrix of dim")
 print(dim(mat(object)))
 nn <- dimnames(object)
 if (nrow(object)>=4 & ncol(object)>=4)
 {
  cat("northwest 4x4:\n")
  tmp <- SparseM::as.matrix(object@mat[1:4,1:4])
  dimnames(tmp) <- list(nn[[1]][1:4], nn[[2]][1:4])
  print(tmp)
 }
 else if (max(dim(mat(object)))<=4) {
   tmp <- SparseM::as.matrix(object@mat)
   dimnames(tmp) <- list(nn[[1]], nn[[2]])
   print(tmp)
 }
 else if (nrow(object)>4) {
   cat("first 4 rows:\n")
   tmp <- SparseM::as.matrix(object@mat[1:4,])
   dimnames(tmp) <- list(nn[[1]][1:4], nn[[2]])
   print(tmp)
 }
 else if (ncol(object)>4) {
   cat("first 4 cols:\n")
   tmp <- SparseM::as.matrix(object@mat[,1:4])
   dimnames(tmp) <- list(nn[[1]], nn[[2]][1:4])
   print(tmp)
 }
 else stop("something wrong with dimensions.")
})


setMethod("t", "namedSparse", function(x) {
 tmp <- t(mat(x))
 tmp <- mkNS(tmp)
 dimnames(tmp) <- dimnames(x)[2:1]
 tmp
})

makeNamedSparse <- function(sm,rn,cn)
 {
 d <- dim(sm)
 if (length(rn)!=d[1]) stop("number of row names does not match dim(sm)[1]")
 if (length(cn)!=d[2]) stop("number of column names does not match dim(sm)[2]")
 new("namedSparse", mat=sm, Dimnames=list(rn,cn))
 }
