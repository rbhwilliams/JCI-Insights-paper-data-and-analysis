revArcs <- function (g) 
{
    tls <- names(eg <- edges(g))
    lel <- unlist(lapply(eg,length))
    tls <- rep(tls,lel)
    tps <- unlist(edges(g))
    ng <- nodes(g)
    nnod <- length(nodes(g))
    tmp <- lapply(split(tls, tps), function(x) list(edges = match(x, 
        ng)))
    full <- list()
    for (i in 1:nnod)
        full[[ ng[i] ]] <- list( edges=tmp[[ ng[i] ]]$edges )
    new("graphNEL", nodes = nodes(g), edgeL = full, edgemode = "directed")
}

