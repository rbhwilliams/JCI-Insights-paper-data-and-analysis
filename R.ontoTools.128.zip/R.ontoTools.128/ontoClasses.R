setClass("ontology",
        representation(name="character",
                        version="character",
                        rDAG="rootedDAG"))
setGeneric("name", function(x)standardGeneric("name"))
setMethod("name", "ontology", function(x)x@name)
setGeneric("OVersion", function(x)standardGeneric("OVersion"))
setMethod("OVersion", "ontology", function(x)x@version)
setGeneric("rDAG", function(x)standardGeneric("rDAG"))
setMethod("rDAG", "ontology", function(x)x@rDAG)
setMethod("show", "ontology", function(object){
        cat(paste("Ontology object ",name(object),", version ",
                OVersion(object),"\n",sep=""))
        cat(paste(" root=",root(rDAG(object))),"\n")
        nterms <- length(tm <- nodes(DAG(rDAG(object))))
        if (nterms > 20) 
                {
                cat(" First 20 terms:\n")
                tm <- tm[1:20]
                }
        else cat(" Terms:\n")
        print(tm)
        }
)

makeOntology <- function( name, version, graph, root ) 
 new("ontology", name=name, version=version, rDAG=
             new("rootedDAG", root=root, DAG=graph))

setGeneric("accessMat", function(object)standardGeneric("accessMat"))
setMethod("accessMat", "ontology", function(object) {
        g <- rDAG(object)
        gm <- getMatrix(g, "child2parent", "sparse")
        d <- max(ontoDepth(g)) #DMdepth(DAG(g),maxd=200)
        tmp <- gm
        for (i in 1:(d-1))
                {
                tmp <- tmp + tmp %*% gm
                tmp@ra <- pmin(1,tmp@ra)
                }
        tmp2 <- new("namedSparse", mat=tmp)
        dimnames(tmp2) <- list(nodes(DAG(g)), nodes(DAG(g)))
        tmp2
        }
)

setClass("OOC",representation(ontology="ontology",
        OOmap="namedSparse"))
setGeneric("ontology",function(x)standardGeneric("ontology"))
setMethod("ontology","OOC",function(x)x@ontology)
setGeneric("OOmap",function(x)standardGeneric("OOmap"))
setMethod("OOmap","OOC",function(x)x@OOmap)
setMethod("show", "OOC", function(object) {
cat("object-ontology complex with ontology:\n")
        show(ontology(object))
cat("object-ontology map:\n")
        show(OOmap(object))
})
makeOOC <- function(ont,map)
 new("OOC", ontology=ont, OOmap=map)
        
setGeneric("coverageMat", function(x) standardGeneric("coverageMat"))
setMethod("coverageMat", "OOC", function(x) 
 {
        too <- OOmap(x)
        tmp <-  too + (too %*% accessMat(ontology(x)))
        tmp@mat@ra <- pmin(1,tmp@mat@ra)
        tmp
})

